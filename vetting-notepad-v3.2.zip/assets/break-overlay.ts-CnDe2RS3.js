import{n as $}from"./break-timer-fy00y0nL.js";var m={},r=null,f=null,v=null;function _({name:t="☕ Tea break",seconds:o=300,totalSeconds:s=o,snooze:x=[2,5,10],onDismiss:A}={}){window.__brk?.stop();const l=document.createElement("div");l.style.cssText="all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none";const i=l.attachShadow({mode:"open"});i.innerHTML=`
    <div class="glow pulse"></div>
    <div class="bar main-bar">
      <span class="name"></span>
      <span class="time-badge"><span class="time"></span></span>
      <div class="snooze-wrap">
        <button type="button" class="snooze-toggle" title="Snooze options" aria-haspopup="true" aria-expanded="false">
          <span>Snooze</span>
          <svg class="chevron" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
        </button>
        <div class="snooze-menu" style="display:none;"></div>
      </div>
      <button class="x" title="Hide popup">×</button>
    </div>
    <div class="bar finish-bar" style="display:none;">
      <span class="finish-title">☕ Break Finished</span>
      <button type="button" class="btn-im-back">I'm Back</button>
    </div>`;const P=`
    .glow{position:fixed;inset:0;pointer-events:none;transition:box-shadow .4s ease}
    .glow.pulse{animation:p var(--d,2.4s) ease-in-out infinite;box-shadow:inset 0 0 70px 12px rgba(var(--c,30,191,138),.5)}
    .glow.static{animation:none;box-shadow:inset 0 0 calc(45px + 20px*var(--p,0)) calc(5px + 8px*var(--p,0)) rgba(var(--c,30,191,138),.42)}
    @keyframes p{
      0%,100%{box-shadow:inset 0 0 calc(50px + 30px*var(--p,0)) calc(6px + 10px*var(--p,0)) rgba(var(--c,30,191,138),calc(.3 + .25*var(--p,0)))}
      50%{box-shadow:inset 0 0 calc(110px + 90px*var(--p,0)) calc(26px + 30px*var(--p,0)) rgba(var(--c,30,191,138),calc(.7 + .3*var(--p,0)))}}
    @media (prefers-reduced-motion:reduce){.glow.pulse{animation:none}}

    .bar{position:fixed;top:8px;left:50%;transform:translateX(-50%);pointer-events:auto;
      display:flex;align-items:center;gap:8px;white-space:nowrap;padding:4px 6px 4px 12px;
      background:#1f2430;color:#f2f5f8;border-radius:999px;font:13px/1 system-ui,sans-serif;
      box-shadow:0 4px 16px rgba(0,0,0,.4),0 0 0 1px rgba(var(--c,30,191,138),.7);
      cursor:grab;user-select:none;touch-action:none;transition:box-shadow .2s ease}
    .bar:active{cursor:grabbing}
    .name{font-weight:700;font-size:12.5px;opacity:.92;letter-spacing:.2px}
    .time-badge{display:inline-flex;align-items:center;padding:3px 9px;border-radius:999px;
      background:rgba(0,0,0,.35);box-shadow:inset 0 0 0 1px rgba(var(--c,30,191,138),.3)}
    .time{font-variant-numeric:tabular-nums;font-weight:800;font-size:16px;color:rgb(var(--c,30,191,138));letter-spacing:.6px}

    .snooze-wrap{position:relative;display:flex;align-items:center}
    .snooze-toggle{all:unset;cursor:pointer;display:flex;align-items:center;gap:4px;
      background:rgba(255,255,255,.08);padding:4px 8px;border-radius:999px;font-size:11.5px;
      color:#d1d7e0;transition:background .15s ease,color .15s ease}
    .snooze-toggle:hover{background:rgba(255,255,255,.15);color:#fff}
    .snooze-toggle.open{background:rgba(var(--c,30,191,138),.25);color:rgb(var(--c,30,191,138))}
    .chevron{transition:transform .2s ease}
    .snooze-toggle.open .chevron{transform:rotate(180deg)}

    .snooze-menu{position:absolute;top:calc(100% + 6px);left:50%;transform:translateX(-50%);
      background:#1c212b;border:1px solid rgba(var(--c,30,191,138),.6);border-radius:10px;
      padding:4px;display:flex;gap:4px;box-shadow:0 8px 24px rgba(0,0,0,.6);z-index:20}
    .snooze-menu button{all:unset;cursor:pointer;background:rgba(255,255,255,.08);padding:5px 9px;
      border-radius:7px;font-size:12px;font-weight:600;color:#f2f5f8;text-align:center}
    .snooze-menu button:hover{background:rgb(var(--c,30,191,138));color:#05281d}

    button.x{all:unset;cursor:pointer;background:rgba(255,255,255,.08);padding:2px 7px;
      border-radius:999px;font-size:14px;line-height:1;color:#a0abb8;margin-left:2px}
    button.x:hover{background:rgba(255,70,60,.25);color:#ff7060}

    /* Post-Break Completion State */
    .finish-bar{background:#1a2520;box-shadow:0 4px 18px rgba(0,0,0,.5),0 0 0 1.5px rgb(var(--c,30,191,138));padding:4px 6px 4px 14px}
    .finish-title{font-weight:700;font-size:13px;color:#f2f5f8;margin-right:4px}
    .btn-im-back{all:unset;cursor:pointer;background:rgb(var(--c,30,191,138));color:#042017;
      font-weight:800;font-size:12.5px;padding:5px 14px;border-radius:999px;
      box-shadow:0 2px 10px rgba(var(--c,30,191,138),.45);letter-spacing:.3px;
      animation:pulseBack 1.8s ease-in-out infinite}
    @keyframes pulseBack{
      0%,100%{transform:scale(1)}
      50%{transform:scale(1.05);box-shadow:0 3px 14px rgba(var(--c,30,191,138),.7)}}
    .btn-im-back:hover{filter:brightness(1.15)}`;try{const e=new CSSStyleSheet;e.replaceSync(P),i.adoptedStyleSheets=[e]}catch{const e=document.createElement("style");e.textContent=P,i.append(e)}const d=i.querySelector(".glow"),b=i.querySelector(".main-bar"),y=i.querySelector(".finish-bar"),M=i.querySelector(".name");M&&(M.textContent=t);const L=i.querySelector(".time"),p=i.querySelector(".snooze-toggle"),c=i.querySelector(".snooze-menu"),B=i.querySelector(".x"),E=i.querySelector(".btn-im-back");let k=o*1e3,S=Date.now()+k,u,z;const N=e=>String(Math.floor(e/60)).padStart(2,"0")+":"+String(e%60).padStart(2,"0"),C=(e,n,a)=>e.map((g,X)=>Math.round(g+(n[X]-g)*a)),j=[30,191,138],D=[255,176,32],H=[255,70,60];let T=-1;function R(e){e=Math.min(1,Math.max(0,e));const n=e<.6?C(j,D,e/.6):C(D,H,(e-.6)/.4);l.style.setProperty("--p",e.toFixed(3)),l.style.setProperty("--c",n.join(","));const a=Math.floor(e*5);a!==T&&(T=a,l.style.setProperty("--d",(2.4-a*.35).toFixed(2)+"s"))}function h(){const e=Math.max(0,Math.round((S-Date.now())/1e3));L&&(L.textContent=N(e));const n=s>0?s:o,a=n-e;R(1-e/n),d&&(a<=30||e<=30&&e>0?(d.classList.add("pulse"),d.classList.remove("static")):(d.classList.remove("pulse"),d.classList.add("static"))),e<=0&&(u&&clearInterval(u),b&&(b.style.display="none"),y&&(y.style.display="flex"),d&&(d.classList.add("pulse"),d.classList.remove("static")))}function I(){u&&clearInterval(u),z&&clearTimeout(z),l.remove(),delete window.__brk,A?.()}function O(e){u&&clearInterval(u),k=S-Date.now(),l.style.display="none",c&&(c.style.display="none"),p&&p.classList.remove("open"),v=Date.now()+e*6e4,z=setTimeout(()=>{v=null,S=Date.now()+k,l.style.display="",u=setInterval(h,1e3),h()},e*6e4)}return x.forEach(e=>{const n=document.createElement("button");n.type="button",n.textContent=e+"m",n.title="Snooze "+e+" minutes",n.onclick=a=>{a.stopPropagation(),O(e)},c&&c.append(n)}),p&&c&&(p.onclick=e=>{e.stopPropagation();const n=c.style.display!=="none";c.style.display=n?"none":"flex",p.classList.toggle("open",!n),p.setAttribute("aria-expanded",String(!n))}),l.addEventListener("pointerdown",e=>{const n=e.target;n instanceof Node&&c&&c.style.display!=="none"&&!c.contains(n)&&!p?.contains(n)&&(c.style.display="none",p?.classList.remove("open"),p?.setAttribute("aria-expanded","false"))}),E&&(E.onclick=e=>{e.stopPropagation(),I()}),B instanceof HTMLElement&&(B.onclick=e=>{e.stopPropagation(),b&&(b.style.display="none")}),[b,y].forEach(e=>{if(!e)return;let n=null;e.addEventListener("pointerdown",a=>{if(a.target instanceof Element&&a.target.closest("button"))return;const g=e.getBoundingClientRect();Object.assign(e.style,{left:g.left+"px",top:g.top+"px",transform:"none"}),n={dx:a.clientX-g.left,dy:a.clientY-g.top},e.setPointerCapture(a.pointerId)}),e.addEventListener("pointermove",a=>{n&&(e.style.left=Math.max(0,Math.min(innerWidth-e.offsetWidth,a.clientX-n.dx))+"px",e.style.top=Math.max(0,Math.min(innerHeight-e.offsetHeight,a.clientY-n.dy))+"px")}),e.addEventListener("pointerup",()=>{n=null})}),document.documentElement.append(l),u=setInterval(h,1e3),h(),window.__brk={stop:I},"Break started. Run __brk.stop() to remove it."}function w(){if(m.showPageOverlay===!1){window.__brk&&(window.__brk.stop(),r=null);return}if(v&&Date.now()<v)return;const t=$(m,new Date);if(f&&f!==t.currentPhase&&(f=null),t.isActive){if(f===t.currentPhase||r===t.currentPhase&&window.__brk)return;r=t.currentPhase;const o=t.currentPhase==="in_lunch",s=o?"🍽 Lunch break":`${t.icon||"☕"} ${t.eventName||"Tea break"}`,x=o?2400:600;_({name:s,seconds:Math.max(1,t.diffSec||x),totalSeconds:x,snooze:o?[5,10,15]:[2,5,10],onDismiss:()=>{f=t.currentPhase,r=null}});return}if(t.isPreBreak){const o=t.currentPhase+"_pre";if(f===o||r===o&&window.__brk)return;r=o;const s=(t.preBreakMinutes||2)*60,x=Math.max(1,t.diffSec||s);_({name:`⏳ Wrap up call (${t.eventName} in ${Math.ceil(x/60)}m)`,seconds:x,totalSeconds:s,snooze:[1,2],onDismiss:()=>{f=o,r=null}});return}!t.isActive&&!t.isPreBreak&&r!=="preview"&&window.__brk&&(window.__brk.stop(),r=null)}window.addEventListener("keydown",t=>{t.key==="Escape"&&window.__brk&&(window.__brk.stop(),r&&(f=r,r=null))});function F(t){return typeof t=="object"&&t!==null&&"type"in t}function q(t){return typeof t=="object"&&t!==null?t:null}typeof chrome<"u"&&chrome.runtime?.onMessage&&chrome.runtime.onMessage.addListener((t,o,s)=>{if(F(t)&&t.type==="VPAD_BREAK_STATE"){if(t.isPreview){r="preview",_({name:t.eventName||"☕ Tea break (Preview)",seconds:t.diffSec||300,totalSeconds:300,snooze:[2,5,10],onDismiss:()=>{r=null}}),s({ok:!0});return}w(),s({ok:!0})}});typeof chrome<"u"&&chrome.storage?.onChanged&&chrome.storage.onChanged.addListener((t,o)=>{if(o==="local"){const s=q(t["vpad.break_schedule"]?.newValue??t["vpad.breakSchedule"]?.newValue);s&&(m=s,w())}});if(typeof chrome<"u"&&chrome.storage?.local)try{chrome.storage.local.get(["vpad.break_schedule","vpad.breakSchedule"],t=>{const o=q(t["vpad.break_schedule"]??t["vpad.breakSchedule"]);o&&(m=o),w(),setInterval(w,1e3)})}catch{}export{_ as breakNotifier};
